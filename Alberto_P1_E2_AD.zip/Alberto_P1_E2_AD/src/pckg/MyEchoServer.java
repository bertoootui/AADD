package pckg;




import java.io.DataInputStream;
import java.io.File;
import java.io.FileReader;
import java.io.FileWriter;
import java.io.IOException;

import java.io.PrintWriter;
import java.net.InetAddress;
import java.net.ServerSocket;
import java.net.Socket;
import java.net.SocketException;
import java.net.UnknownHostException;

import java.time.LocalDateTime;
import java.time.format.DateTimeFormatter;
import java.util.Properties;

public class MyEchoServer {

	

	public static void main(String[] args) throws SocketException {
		
	
		
		
		
		

		
		
		
		
		String ip = null;
		InetAddress dirIp = null;
		LocalDateTime date = LocalDateTime.now();
		DateTimeFormatter myFormatObj = DateTimeFormatter.ofPattern("dd/MM/yyyy HH:mm:ss");
		try {
			dirIp = InetAddress.getLocalHost();
			ip = dirIp.toString();
			
		} catch (UnknownHostException e1) {
			// TODO Auto-generated catch block
			e1.printStackTrace();
		}
		boolean end = true;
		String salida = "";
		ServerSocket myserver;
		Socket mysocket = null;
		DataInputStream flujo_entrada = null;
		FileWriter fw = null;
		PrintWriter pw = null;
		String fecha = date.format(myFormatObj);
		try {
			Properties p = new Properties();
			
			FileReader fr = new FileReader(ficheroprops());
			p.load(fr);
			fw = new FileWriter(ficherologs(), true);	
			 pw = new PrintWriter(fw);
			String port = p.getProperty("puerto");
			int puerto = Integer.parseInt(port);
			 myserver = new ServerSocket(puerto);
			 mysocket = myserver.accept();
			 pw.write("["+fecha+"]" +"["+ip.replaceAll("DESKTOP-AA9222B/", "")+"]"+ ":Se ha establecido la conexi�n\n");
			 flujo_entrada = new DataInputStream(mysocket.getInputStream());
			 
			do {
				salida = flujo_entrada.readUTF();
				if(salida.equals("exit"))
					{
					System.out.println("la conexi�n ha finalizado");
					pw.write("["+fecha+"]" +"["+ip.replaceAll("DESKTOP-AA9222B/", "")+"]"+ ":La conexi�n ha finalizado\n");
					break;
					}
					
			System.out.println(salida + " ");
			
			pw.write("["+fecha+"]" +"["+ip.replaceAll("DESKTOP-AA9222B/", "")+"]"+ ":"+salida+"\n");			
			
			
			
		}//end while
			while(end);
			fw.close();
			pw.close();
			flujo_entrada.close();
			mysocket.close();
			myserver.close();
			
			
		}//end try 
		
		
		catch (IOException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
			
		
	}//end main

	
	
	//METODOS 
	
	
	
	private static File ficheroprops() {
		File props = new File(".\\src\\Props\\Serverprops.properties");
		
		if(props.exists()) System.out.println("El fichero serverprops ya est� creado");
		else
		{
			try {
				props.createNewFile();
				FileWriter fw = new FileWriter(props);
				PrintWriter pw= new PrintWriter(fw);
				pw.write("#Fichero de configuraci�n echo.props"+"\n"+ "puerto=2222"+"\n");
				fw.close();
				pw.close();
			} catch (IOException e) {
				// TODO Auto-generated catch block
				e.printStackTrace();
			}
			System.out.println("Se ha creado el fichero serverprops");
		}//end else
		
		return props;
		
	}//end fichero logs

	private static File ficherologs() {
		File logs = new File(".\\src\\logs\\logs.txt");
		
		if(logs.exists()) System.out.println("El fichero logs ya est� creado");
		else
		{
			try {
				logs.createNewFile();
				
			} catch (IOException e) {
				// TODO Auto-generated catch block
				e.printStackTrace();
			}
			System.out.println("Se ha creado el fichero logs");
		}//end else
		
		return logs;
	}//end fichero logs

}
