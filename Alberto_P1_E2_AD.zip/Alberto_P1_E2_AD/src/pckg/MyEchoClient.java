package pckg;


import java.io.DataOutputStream;
import java.io.File;
import java.io.FileNotFoundException;
import java.io.FileReader;
import java.io.FileWriter;
import java.io.IOException;

import java.io.PrintWriter;
import java.net.Socket;
import java.util.Properties;
import java.util.Scanner;

public class MyEchoClient {

	public static void main(String[] args) {
		File props = new File("C:\\Users\\fabet\\eclipse-workspace\\Alberto_P1_E2_AD\\src\\Props\\clientprops.properties");
		
		if(props.exists()) System.out.println("El fichero Clientprops ya est� creado");
		else
		{
			try {
				props.createNewFile();
				FileWriter fw = new FileWriter(props);
				PrintWriter pw= new PrintWriter(fw);
				pw.write("#Fichero de configuraci�n echo.props"+"\n"+ "puerto=2222"+"\n"+"direccion=127.0.0.1");
				fw.close();
				pw.close();
			} catch (IOException e) {
				// TODO Auto-generated catch block
				e.printStackTrace();
			}
			System.out.println("Se ha creado el fichero Clientprops");
		}
		String salida = "";
		Scanner teclado = new Scanner(System.in);
		//while(!salida.equals("exit")) {
			
		try {
			Properties p = new Properties();
			
			FileReader fr = new FileReader(props);
			p.load(fr);
			
			String ip = p.getProperty("direccion");
			System.out.println(ip);
			
			String puerto = p.getProperty("puerto");
			
			int port = Integer.parseInt(puerto);
			System.out.println(port);
			Socket mysocket = new Socket(ip,2222);
			DataOutputStream flujo_salida = new DataOutputStream(mysocket.getOutputStream());
			while(true) {
			
			System.out.println("Introduzca el texto que desea escribir");
			System.out.println("Si desea salir teclee exit");
			salida = teclado.nextLine();
			
					
			flujo_salida.writeUTF(salida);
			flujo_salida.flush();
			
			if(salida.equalsIgnoreCase("exit"))break;
			
		
			}//end while
			mysocket.close();
			flujo_salida.close();
			teclado.close();
			
			fr.close();
			
		
		
		} catch (FileNotFoundException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		} catch (IOException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}	
			
		
		//}//end while
		
		
		
		
		
		
		
		
		
		
		
		
		
		

	}

}
