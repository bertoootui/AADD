package activity;

import java.io.BufferedReader;
import java.io.BufferedWriter;
import java.io.File;
import java.io.FileReader;
import java.io.FileWriter;
import java.io.IOException;
import java.io.InputStreamReader;
import java.io.PrintWriter;
import java.util.ArrayList;
import java.util.Date;
import java.util.Scanner;

public class Ejercicio_1 {

	public static void main(String[] args) {
		
		String  log = ".\\src\\log";
		String  net = ".\\src\\net";
		
		File Flog = new File(log);
		File Fnet = new File(net);
		
		if(Flog.exists()) System.out.println("El directorio Log ya est� creado");
		else
		{
			Flog.mkdir();
			System.out.println("Se ha creado el directorio Log");
		}
		if (Fnet.exists()) System.out.println("El directorio Net ya est� creado");
		else
		{
			Fnet.mkdir();
			System.out.println("Se ha creado el directorio Net");
		}
		
		System.out.println("eliga una opcion");
		Scanner teclado = new Scanner(System.in);
		int num = teclado.nextInt();
		
		if(num == 1)
		Registrolog(log);
		else
		Registronet(net);
		
		
		

	}

	private static void Registronet(String net) {
		int i = 0;
		
		//Primera ejecuci�n del programa
		String rutanet = net +"\\netStat_" + i +".txt";
		File net2 = new File(rutanet);
		
		if(net2.exists()) System.out.println("El fichero "+rutanet+" ya est� creado");
		else
		{
			try {
				net2.createNewFile();
			} catch (IOException e) {
				// TODO Auto-generated catch block
				e.printStackTrace();
			}
			System.out.println("Se ha creado el fichero" + rutanet);
		}//end else
		
		//fin primera ejecuci�n
		
		
		try {
			
			
			
			Process process = Runtime.getRuntime().exec("netstat -n");
			
			BufferedReader br2 = new BufferedReader(new InputStreamReader(process.getInputStream()));
			String line = null;;
			int x = 0;
			int y = 0;
			String s = null;
			int a = 0;
			FileReader fr = new FileReader(net2);
			BufferedReader br = new BufferedReader(fr);
			
			while(a!=-1)
			{
				
				if(net2.exists())
				{
					
					i++;
					net2 = new File(net +"\\netStat_" + i +".txt");
					
				}
				else
				{
					i--;
					net2 = new File(net +"\\netStat_" + i +".txt");
					a = -1;
					System.out.println(a);
					
				}
				System.out.println(net2.getName());
				br = new BufferedReader(new FileReader(net2));
				x = 0;
			}//end while
			FileWriter fw = new FileWriter(net2,true);
			PrintWriter pw = new PrintWriter(fw); 
			while(br.readLine()!=null)x++;
			
			
			
			
			
			
			while((line = br2.readLine())!=null)
			{
				if(x+y>=200) {
					
					i++;
					net2 = new File(net +"\\netStat_" + i +".txt");
					y = 0;
					if(net2.exists()) System.out.println("El fichero "+net2.getName()+" ya est� creado");
					else
					{
						try {
							net2.createNewFile();
						} catch (IOException e) {
							// TODO Auto-generated catch block
							e.printStackTrace();
						}
						System.out.println("Se ha creado el fichero " + net2.getName());
					}//end else
					pw = new PrintWriter(new FileWriter(net2));
					while((line = br2.readLine())!=null)
					{
						//s = line.toString();
						//if (s.equals("null")) break;
						pw.write(line+"\n");
					}
					
					
					
					}//end if
				y++;
				
				//if ((s = line.toString()).equals(null)) break;
				pw.write(line +"\n");
				
			}//end while
	
			
			
			
			fw.close();
			pw.close();
			fr.close();
			br.close();
			br2.close();
			
		} catch (IOException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		
		
		
	}

	public static  void Registrolog(String log) {
		
		String rutalog = System.getProperty("user.name") + ".txt";
		File log2 = new File( log+"\\"+rutalog);
		Date fech = new Date();
		if(log2.exists()) System.out.println("El fichero "+rutalog+" ya est� creado");
		else
		{
			try {
				log2.createNewFile();
			} catch (IOException e) {
				// TODO Auto-generated catch block
				e.printStackTrace();
			}
			System.out.println("Se ha creado el fichero" + rutalog);
		}
		
		
		try {
			FileWriter fw = new FileWriter(log2,true);
			PrintWriter pw = new PrintWriter(fw);
			
			FileReader fr = new FileReader(log2);
			BufferedReader br = new BufferedReader(fr);
			String fecha = fech.toString();
			System.out.println(fecha);
		
			//comprobamos si el archivo est� vac�o para que empiece a esciribir en la primera l�nea
			if(br.ready() == false)
			pw.write(fecha);
			else pw.write("\n" + fecha);
			fw.close();
			pw.close();
			fr.close();
			br.close();
		} catch (IOException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		
	}

}
